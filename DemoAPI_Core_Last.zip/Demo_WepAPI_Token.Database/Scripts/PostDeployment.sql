﻿
EXEC [dbo].[AddUser] 'b.picsou@outlook.com', 'Balthazar', 'Test1234=',0;
EXEC [dbo].[AddUser] 'z.vanderquack@outlook.com', 'Zaza', 'Test1234=',0;
EXEC [dbo].[AddUser] 'test@test.com', 'Testeur', 'Test1234=', 1;
