﻿CREATE VIEW [dbo].[V_UserApp]
AS
SELECT [Id], [Email], [Username], [IsAdmin]
FROM [dbo].[UserApp]
